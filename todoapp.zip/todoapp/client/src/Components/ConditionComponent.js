export function ConditionComponent(props) {
    return(
        <h1>
            This is my component
        </h1>
    )
}