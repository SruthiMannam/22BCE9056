export const dummy = [
    {
        _id: 1,
        title: "Do Laundry",
        done: false
    },
    {
        _id: 2,
        title: "Finish assignments!",
        done: true
    },
    {
        _id: 3,
        title: "Grocery shopping",
        done: false
    },
    {
        _id: 4,
        title: "Clean the house",
        done: true
    },
    {
        _id: 5,
        title: "Pay bills",
        done: false
    },
    {
        _id: 6,
        title: "Read a book",
        done: true
    },
    {
        _id: 7,
        title: "Exercise",
        done: false
    },
    {
        _id: 8,
        title: "Call parents",
        done: true
    },
    {
        _id: 9,
        title: "Plan weekend trip",
        done: false
    },
    {
        _id: 10,
        title: "Write blog post",
        done: true
    },
    {
        _id: 11,
        title: "Water plants",
        done: false
    },
    {
        _id: 12,
        title: "Schedule dentist appointment",
        done: true
    },
    {
        _id: 13,
        title: "Update resume",
        done: false
    },
    {
        _id: 14,
        title: "Organize desk",
        done: true
    },
    {
        _id: 15,
        title: "Buy birthday gift",
        done: false
    }
];
