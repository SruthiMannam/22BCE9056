import {TODO} from '../Views/TODO/TODO';


const MyURLs = [
    {
        path: "/",
        view: TODO,
        title: "My TODOs"
    }
]

export default MyURLs;